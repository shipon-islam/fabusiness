const Card = ({ children }) => (
  <div className="bg-white rounded-xl p-6 shadow-md">{children}</div>
);
export default Card;
