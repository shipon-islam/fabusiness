import FeedbackForm from "./FeedbackForm";
export default async function ClientFeedback() {
  

  return (
    <div>
      <FeedbackForm />     
    </div>
  );
}
